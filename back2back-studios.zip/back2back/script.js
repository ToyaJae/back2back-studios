// Mobile nav toggle
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');

hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

// Close nav when a link is clicked
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
  });
});

// Set min date to today for the date picker
const dateInput = document.getElementById('date');
const today = new Date().toISOString().split('T')[0];
dateInput.setAttribute('min', today);

// Booking form submission
function submitBooking() {
  const name = document.getElementById('name').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const email = document.getElementById('email').value.trim();
  const service = document.getElementById('service').value;
  const date = document.getElementById('date').value;
  const time = document.getElementById('time').value;

  if (!name || !phone || !email || !service || !date || !time) {
    alert('Please fill out all fields before submitting.');
    return;
  }

  // Format the date nicely
  const dateObj = new Date(date + 'T00:00:00');
  const formattedDate = dateObj.toLocaleDateString('en-US', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });

  // Save booking to localStorage
  const booking = { name, phone, email, service, date, time, submittedAt: new Date().toISOString() };
  const existing = JSON.parse(localStorage.getItem('b2b_bookings') || '[]');
  existing.push(booking);
  localStorage.setItem('b2b_bookings', JSON.stringify(existing));

  // Show confirmation
  document.getElementById('confirmMsg').textContent =
    `Thanks ${name}! Your request for a ${service} on ${formattedDate} at ${time} has been received.`;

  document.getElementById('bookingForm').style.display = 'none';
  document.getElementById('bookingConfirm').style.display = 'block';
}

// Reset form
function resetForm() {
  document.getElementById('name').value = '';
  document.getElementById('phone').value = '';
  document.getElementById('email').value = '';
  document.getElementById('service').value = '';
  document.getElementById('date').value = '';
  document.getElementById('time').value = '';

  document.getElementById('bookingForm').style.display = 'block';
  document.getElementById('bookingConfirm').style.display = 'none';
}
