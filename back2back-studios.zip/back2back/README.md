# Back 2 Back Studios – Salon Website

**Assignment 7B – Capstone Final Project**
ING 2262 CRED

---

## Project Overview

Back 2 Back Studios is a responsive salon website that allows clients to view services and pricing, and submit appointment booking requests online. The site is built with HTML, CSS, and JavaScript and uses localStorage as a modern web feature to save booking data on the client side.

---

## Features

- **Home page** with a welcome hero section and call-to-action button
- **Services section** displaying 6 salon services with descriptions and starting prices
- **Booking form** where clients can request an appointment by selecting a service, date, and time
- **Confirmation message** shown after a successful booking request
- **localStorage integration** – booking requests are saved in the browser so they persist between sessions
- **Responsive design** – works on mobile, tablet, and desktop screens
- **Mobile navigation** – hamburger menu for smaller screens

---

## Technologies Used

| Tool | Purpose |
|------|---------|
| HTML5 | Page structure and content |
| CSS3 | Styling, layout, and responsive design |
| JavaScript | Form logic, interactivity, localStorage |
| Google Fonts | Custom typography (Playfair Display + Jost) |
| GitHub Pages | Hosting and deployment |

---

## How to Run Locally

1. Download or clone this repository
2. Open `index.html` in any web browser
3. No installation or setup required

---

## Deployment

This site is deployed and hosted on **GitHub Pages**.

Live URL: `https://[your-username].github.io/back2back-studios`

---

## File Structure

```
back2back-studios/
├── index.html      # Main HTML page
├── style.css       # All styles and responsive layout
├── script.js       # Booking form logic and localStorage
└── README.md       # Project documentation
```

---

*Created for ING 2262 CRED – Capstone Final Project, May 2026*
